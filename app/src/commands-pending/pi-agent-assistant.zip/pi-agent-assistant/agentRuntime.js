import { Agent } from "@earendil-works/pi-agent-core";
import { streamSimple } from "@earendil-works/pi-ai";
import { createOpenAiCompatibleModel } from "./model.js";
import { createDeepWikiTool } from "./tools/deepwiki.js";
import { createGeneratePluginTool } from "./tools/generatePlugin.js";
import { createShellTool } from "./tools/shell.js";
import { createValidatePluginTool } from "./tools/validatePlugin.js";

const TASK_TTL_MS = 30 * 60 * 1000;
const tasks = new Map();

const SYSTEM_PROMPT = `
你是 LookBack 的 Pi Agent 命令助手，始终使用中文工作。

你的核心目标：
1. 帮用户设计、生成、验证和导入 LookBack 外部命令。
2. 默认优先生成单文件 .jsx command；只有复杂能力、Node 依赖、服务端能力或多文件维护价值明确时，才生成 folder command。
3. 所有实现必须是生产级：清晰简洁、高内聚低耦合、可维护、可测试，不写 mock、TODO、placeholder 或降级实现。
4. 不修改主应用代码，除非用户明确要求。commands-pending 任务不得耦合主应用。

LookBack command 关键约定：
- 必须导出 export const config。
- 单文件命令不要 import，不要 export default，不要 TypeScript 语法。
- folder command 使用 package.json 的 lookback.id / lookback.ui / lookback.server。
- UI 文案必须通过 command 自带 i18n。
- 复杂 folder command 可以参考 follow-practice 的 index.jsx、server.js、package.json 结构。
- 运行时能力只使用 context 暴露的 React、hooks、actions、store、config、shell、components。
- React 事件处理里直接读写 state，渲染读取 snapshot；如果外部 UI 无法导入 valtio，保持局部状态集中管理，避免散乱。
- 数组状态不要整段替换 Valtio attr，优先 push、splice、mutable 修改。
- 配置如果属于 command 自己，按用户要求存 localStorage；主应用配置必须走 localApi。

可用工具：
- generate_plugin：写入并导入插件。调用前必须给出完整文件内容。
- validate_plugin：验证插件 manifest、入口、语法和 server 可导入。
- shell：执行扩展能力任务，参数必须使用 args 数组。
- deepwiki_search：检索 moayuisuda/lookback 仓库知识。遇到 API 或架构不确定时先查。

输出策略：
- 需要写代码时，先用工具落盘和验证，再向用户报告结果。
- 不要只给建议；除非用户只要求设计，否则应推进到可运行产物。
- 工具失败时，根据错误修复并重试，不做无意义兜底。
`.trim();

const createTaskId = () =>
  `task_${Date.now().toString(36)}_${Math.random().toString(16).slice(2)}`;

const getMessageText = (message) => {
  const content = message?.content;
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content
    .filter((block) => block?.type === "text")
    .map((block) => block.text)
    .join("");
};

const normalizeMessages = (messages) =>
  Array.isArray(messages)
    ? messages.filter((message) =>
        ["user", "assistant", "toolResult"].includes(String(message?.role || "")),
      )
    : [];

const serializeMessage = (message) => ({
  role: message.role,
  text: getMessageText(message),
  raw: message,
});

const normalizeEvent = (event) => {
  if (event.type === "message_start" || event.type === "message_end") {
    return {
      type: event.type,
      role: event.message?.role || "",
      message: serializeMessage(event.message || {}),
    };
  }
  if (event.type === "message_update") {
    const assistantEvent = event.assistantMessageEvent;
    return {
      type: event.type,
      assistantEventType: assistantEvent?.type || "",
      delta: assistantEvent?.type === "text_delta" ? assistantEvent.delta : "",
      message: event.message ? serializeMessage(event.message) : null,
    };
  }
  if (event.type === "tool_execution_start") {
    return {
      type: event.type,
      toolCallId: event.toolCallId,
      toolName: event.toolName,
      args: event.args,
    };
  }
  if (event.type === "tool_execution_update") {
    return {
      type: event.type,
      toolCallId: event.toolCallId,
      partialResult: event.partialResult,
    };
  }
  if (event.type === "tool_execution_end") {
    return {
      type: event.type,
      toolCallId: event.toolCallId,
      toolName: event.toolName,
      result: event.result,
      isError: event.isError === true,
    };
  }
  if (event.type === "turn_end") {
    return {
      type: event.type,
      message: serializeMessage(event.message || {}),
      toolResults: Array.isArray(event.toolResults)
        ? event.toolResults.map(serializeMessage)
        : [],
    };
  }
  return { type: event.type };
};

const createRuntimeTools = (runtime) => [
  createGeneratePluginTool(runtime),
  createValidatePluginTool(runtime),
  createShellTool(),
  createDeepWikiTool(),
];

const createTask = () => {
  const task = {
    id: createTaskId(),
    cursor: 0,
    events: [],
    status: "running",
    error: "",
    result: null,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    agent: null,
  };
  tasks.set(task.id, task);
  return task;
};

const pushTaskEvent = (task, event) => {
  task.cursor += 1;
  task.updatedAt = Date.now();
  task.events.push({
    cursor: task.cursor,
    event,
  });
  if (task.events.length > 800) {
    task.events.splice(0, task.events.length - 800);
  }
};

const cleanupTasks = () => {
  const now = Date.now();
  for (const [taskId, task] of tasks.entries()) {
    if (task.status === "running") continue;
    if (now - task.updatedAt > TASK_TTL_MS) tasks.delete(taskId);
  }
};

export const startTurn = async (payload, context) => {
  cleanupTasks();
  const settings = payload?.settings || {};
  const apiKey = String(settings.apiKey || "").trim();
  const prompt = String(payload?.prompt || "").trim();
  if (!apiKey) throw new Error("请先配置 API Key");
  if (!prompt) throw new Error("请输入消息");

  const task = createTask();
  const model = createOpenAiCompatibleModel(settings);
  const runtime = {
    storageDir: context.storageDir,
    commandDir: context.commandDir,
    pluginDir: context.pluginDir,
  };

  const agent = new Agent({
    initialState: {
      systemPrompt: SYSTEM_PROMPT,
      model,
      messages: normalizeMessages(payload?.messages),
      tools: createRuntimeTools(runtime),
      thinkingLevel: "off",
    },
    streamFn: streamSimple,
    getApiKey: () => apiKey,
    toolExecution: "sequential",
    convertToLlm: (messages) =>
      messages.filter((message) =>
        ["user", "assistant", "toolResult"].includes(String(message?.role || "")),
      ),
  });

  task.agent = agent;
  agent.subscribe((event) => {
    pushTaskEvent(task, normalizeEvent(event));
  });

  void agent
    .prompt(prompt)
    .then(() => {
      task.status = "completed";
      task.result = {
        messages: agent.state.messages,
      };
      task.updatedAt = Date.now();
    })
    .catch((error) => {
      task.status = "failed";
      task.error = error instanceof Error ? error.message : String(error);
      task.updatedAt = Date.now();
      pushTaskEvent(task, { type: "error", error: task.error });
    });

  return { taskId: task.id };
};

export const pollTurn = async (payload) => {
  cleanupTasks();
  const taskId = String(payload?.taskId || "").trim();
  const after = Number(payload?.cursor || 0);
  const task = tasks.get(taskId);
  if (!task) throw new Error("任务不存在或已过期");
  return {
    taskId,
    status: task.status,
    cursor: task.cursor,
    events: task.events.filter((entry) => entry.cursor > after),
    result: task.status === "completed" ? task.result : null,
    error: task.error,
  };
};

export const cancelTurn = async (payload) => {
  const taskId = String(payload?.taskId || "").trim();
  const task = tasks.get(taskId);
  if (!task) return { success: true };
  task.agent?.abort?.();
  task.status = "cancelled";
  task.updatedAt = Date.now();
  pushTaskEvent(task, { type: "cancelled" });
  return { success: true };
};

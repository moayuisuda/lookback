import { Agent } from "@earendil-works/pi-agent-core";
import { streamSimple } from "@earendil-works/pi-ai";
import { createOpenAiCompatibleModel } from "./model.js";
import { createDeepWikiTool } from "./tools/deepwiki.js";
import { createImageSearchTool } from "./tools/imageSearch.js";
import { createImportPluginTool } from "./tools/importPlugin.js";
import { createSelectedImagePathsTool } from "./tools/selectedImagePaths.js";
import { createShellTool } from "./tools/shell.js";
import { createSystemInfo, formatSystemInfoForPrompt } from "./systemInfo.js";

const TASK_TTL_MS = 30 * 60 * 1000;
const SESSION_TTL_MS = 2 * 60 * 60 * 1000;
const MAX_TOTAL_TOOL_CALLS = 50;
const TOOL_CALL_LIMITS = {
  deepwiki_search: 3,
  image_search: 5,
  import_plugin: 5,
};
const tasks = new Map();
const sessions = new Map();

const BASE_SYSTEM_PROMPT = `
你是 Ira，LookBack 的常驻助手。你温和、敏锐、可靠，有一点自己的判断力；你不是复读用户需求的工具，而是会主动把模糊想法整理成清晰工作流、创作方案或可运行产物的协作者。始终使用中文工作，除非用户明确要求其他语言。

你的核心目标：使用注册的最佳工具，帮用户使用 LookBack 整理参考、规划画布、排查问题、改善工作流，并在需要时设计、生成、验证和导入外部命令。

输出策略：
- 需要写代码时，先用工具落盘和验证，再向用户报告结果。
- 不要只给建议；除非用户只要求设计，否则应推进到可运行产物。
- 工具失败时，根据错误修复并重试，不做无意义兜底。
- 面向用户的回答使用 Markdown。图片必须使用标准 Markdown 图片语法：感叹号、方括号图片说明、圆括号 https 图片地址；不要只写图片名或 alt 文本。
- 语气自然、短促、有人味；说明关键判断，不堆长篇。
- 每轮都必须有回复说明情况，不能一连串工具调完了，没有任何回复。可以多轮 tool 后统一回复，但不能啥都不回复。
- 用最高效的方式解决用户问题，不要为了复杂而复杂。

概念：
插件、命令、拓展功能等，都是指的 LookBack 外部命令

生成 LookBack 外部命令时：
- 用 shell 查看 https://github.com/moayuisuda/lookback/blob/main/llm.txt 了解如何写插件，只可使用前面文档的单文件 jsx 形式，不可使用文件夹形式的插件（不对外）。
- shell 工具的 command 参数就是完整 shell 命令字符串；需要写长文件时，直接用 shell 把完整文件或文件夹写到临时路径。
- import_plugin 只接收 sourcePath 文件/文件夹绝对路径，导入成功后会自动清理该临时源路径。
- import_plugin 失败后必须先根据错误原因修复代码，不要连续导入同一套未修复方案。
`.trim();

const formatUserRulesForPrompt = (userRules) => {
  const rules = String(userRules || "").trim();
  if (!rules) return "";
  return `用户规则：\n${rules}`;
};

const buildSystemPrompt = (systemInfo, settings) =>
  [
    BASE_SYSTEM_PROMPT,
    formatUserRulesForPrompt(settings?.userRules),
    formatSystemInfoForPrompt(systemInfo),
  ].filter(Boolean).join("\n\n");

const createTaskId = () =>
  `task_${Date.now().toString(36)}_${Math.random().toString(16).slice(2)}`;

const getMessageText = (message) => {
  if (message?.errorMessage) return String(message.errorMessage);
  const content = message?.content;
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content
    .filter((block) => block?.type === "text")
    .map((block) => block.text)
    .join("");
};

const createEmptyUsage = () => ({
  input: 0,
  output: 0,
  cacheRead: 0,
  cacheWrite: 0,
  totalTokens: 0,
  cost: {
    input: 0,
    output: 0,
    cacheRead: 0,
    cacheWrite: 0,
    total: 0,
  },
});

const cloneJsonValue = (value) => {
  if (value === undefined) return undefined;
  return JSON.parse(JSON.stringify(value));
};

const toContentBlocks = (content, allowedTypes) => {
  if (typeof content === "string") return [{ type: "text", text: content }];
  if (!Array.isArray(content)) return [];
  return content
    .map((block) => {
      if (!block || typeof block !== "object" || !allowedTypes.has(block.type)) return null;
      return cloneJsonValue(block);
    })
    .filter(Boolean);
};

const getStoredAssistantContent = (message) => {
  const content = toContentBlocks(message.content, new Set(["text", "thinking", "toolCall"]));
  const hasVisibleText = content.some((block) => block.type === "text" && block.text?.trim());
  if (content.length > 0 && (hasVisibleText || content.some((block) => block.type === "toolCall"))) {
    return content;
  }
  const text = getMessageText(message).trim();
  return text ? [{ type: "text", text }] : [];
};

const withCommonMessageFields = (target, message) => {
  if (message.timestamp) target.timestamp = message.timestamp;
  if (message.turnId) target.turnId = message.turnId;
  return target;
};

const toStoredMessage = (message) => {
  if (!message || typeof message !== "object") return null;
  const role = String(message.role || "");
  if (role === "user") {
    const content = Array.isArray(message.content)
      ? toContentBlocks(message.content, new Set(["text", "image"]))
      : getMessageText(message).trim();
    if ((Array.isArray(content) && content.length === 0) || (!Array.isArray(content) && !content)) return null;
    return withCommonMessageFields({ role, content }, message);
  }

  if (role === "assistant") {
    const content = getStoredAssistantContent(message);
    if (content.length === 0) return null;
    const next = withCommonMessageFields(
      {
        role,
        content,
        api: message.api,
        provider: message.provider,
        model: message.model,
        responseModel: message.responseModel,
        responseId: message.responseId,
        diagnostics: cloneJsonValue(message.diagnostics),
        usage: cloneJsonValue(message.usage),
        stopReason: message.stopReason || "stop",
      },
      message,
    );
    if (message.errorMessage) next.errorMessage = String(message.errorMessage);
    return next;
  }

  if (role === "toolResult") {
    const content = toContentBlocks(message.content, new Set(["text", "image"]));
    if (!message.toolCallId || !message.toolName || content.length === 0) return null;
    return withCommonMessageFields(
      {
        role,
        toolCallId: message.toolCallId,
        toolName: message.toolName,
        content,
        details: cloneJsonValue(message.details),
        isError: message.isError === true,
      },
      message,
    );
  }

  return null;
};

const toStoredMessages = (messages) =>
  Array.isArray(messages) ? messages.map(toStoredMessage).filter(Boolean) : [];

const hasToolTranscriptForTurn = (messages, turnId) =>
  messages.some(
    (message) =>
      message?.turnId === turnId &&
      (message.role === "toolResult" ||
        (message.role === "assistant" &&
          Array.isArray(message.content) &&
          message.content.some((block) => block?.type === "toolCall"))),
  );

const getToolResultContent = (result) => {
  const content = toContentBlocks(result?.content, new Set(["text", "image"]));
  if (content.length > 0) return content;
  const text = getToolResultContentText(result);
  return text ? [{ type: "text", text }] : [];
};

const getToolCallsByTurn = (toolEvents) => {
  const callsByTurn = new Map();
  for (const event of Array.isArray(toolEvents) ? toolEvents : []) {
    if (!event?.turnId || !event.toolCallId) continue;
    if (event.type !== "tool_execution_start" && event.type !== "tool_execution_end") continue;

    const calls = callsByTurn.get(event.turnId) || [];
    let call = calls.find((item) => item.toolCallId === event.toolCallId);
    if (!call) {
      call = {
        toolCallId: event.toolCallId,
        toolName: event.toolName || "",
        args: {},
        result: null,
        isError: false,
      };
      calls.push(call);
      callsByTurn.set(event.turnId, calls);
    }

    if (event.toolName) call.toolName = event.toolName;
    if (event.type === "tool_execution_start") call.args = cloneJsonValue(event.args || {});
    if (event.type === "tool_execution_end") {
      call.result = event.result || null;
      call.isError = event.isError === true;
    }
  }
  return callsByTurn;
};

const createToolTranscriptMessages = (turnId, calls, model, timestamp) => {
  const completedCalls = calls
    .map((call) => {
      const content = getToolResultContent(call.result);
      if (!call.toolName || content.length === 0) return null;
      return {
        ...call,
        content,
      };
    })
    .filter(Boolean);
  if (completedCalls.length === 0) return [];

  return [
    {
      role: "assistant",
      content: completedCalls.map((call) => ({
        type: "toolCall",
        id: call.toolCallId,
        name: call.toolName,
        arguments: call.args || {},
      })),
      api: model.api,
      provider: model.provider,
      model: model.id,
      usage: createEmptyUsage(),
      stopReason: "toolUse",
      timestamp,
      turnId,
    },
    ...completedCalls.map((call, index) => ({
      role: "toolResult",
      toolCallId: call.toolCallId,
      toolName: call.toolName,
      content: call.content,
      details: cloneJsonValue(call.result?.details),
      isError: call.isError,
      timestamp: timestamp + index + 1,
      turnId,
    })),
  ];
};

const restoreToolTranscriptFromEvents = (messages, toolEvents, model) => {
  const storedMessages = toStoredMessages(messages);
  const callsByTurn = getToolCallsByTurn(toolEvents);
  if (callsByTurn.size === 0) return storedMessages;

  const restored = [];
  for (const message of storedMessages) {
    restored.push(message);
    if (message.role !== "user" || !message.turnId) continue;
    if (hasToolTranscriptForTurn(storedMessages, message.turnId)) continue;

    restored.push(
      ...createToolTranscriptMessages(
        message.turnId,
        callsByTurn.get(message.turnId) || [],
        model,
        Number(message.timestamp || Date.now()) + 1,
      ),
    );
  }
  return restored;
};

const normalizeMessageForLlm = (message) => {
  if (!message || typeof message !== "object") return null;
  const role = String(message.role || "");
  if (role !== "user" && role !== "assistant" && role !== "toolResult") return message;
  return toStoredMessage(message);
};

const normalizeMessagesForLlm = (messages) =>
  Array.isArray(messages) ? messages.map(normalizeMessageForLlm).filter(Boolean) : [];

const serializeMessage = (message) => ({
  role: message.role,
  text: getMessageText(message),
  raw: message,
});

const getErrorMessage = (error) => {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  if (error?.message) return String(error.message);
  try {
    return JSON.stringify(error);
  } catch {
    return String(error);
  }
};

const serializeToolError = (error) => ({
  name: error instanceof Error ? error.name : String(error?.name || "Error"),
  message: getErrorMessage(error),
});

const toToolFailureResult = (toolName, error) => {
  const toolError = serializeToolError(error);
  return {
    content: [
      {
        type: "text",
        text: `${toolName} 执行失败：${toolError.message}`,
      },
    ],
    details: {
      toolError,
    },
  };
};

const normalizeToolResult = (result, isError) => {
  if (!isError) return result;
  if (result?.details?.toolError) return result;
  return toToolFailureResult("tool", result);
};

const normalizeEvent = (event) => {
  if (event.type === "message_start" || event.type === "message_end") {
    return {
      type: event.type,
      role: event.message?.role || "",
      message: serializeMessage(event.message || {}),
    };
  }
  if (event.type === "message_update") {
    const assistantEvent = event.assistantMessageEvent;
    return {
      type: event.type,
      assistantEventType: assistantEvent?.type || "",
      delta: assistantEvent?.type === "text_delta" ? assistantEvent.delta : "",
      message: event.message ? serializeMessage(event.message) : null,
    };
  }
  if (event.type === "tool_execution_start") {
    return {
      type: event.type,
      toolCallId: event.toolCallId,
      toolName: event.toolName,
      args: event.args,
    };
  }
  if (event.type === "tool_execution_update") {
    return {
      type: event.type,
      toolCallId: event.toolCallId,
      partialResult: event.partialResult,
    };
  }
  if (event.type === "tool_execution_end") {
    return {
      type: event.type,
      toolCallId: event.toolCallId,
      toolName: event.toolName,
      result: normalizeToolResult(event.result, event.isError === true),
      isError: event.isError === true,
    };
  }
  if (event.type === "turn_end") {
    return {
      type: event.type,
      message: serializeMessage(event.message || {}),
      toolResults: Array.isArray(event.toolResults)
        ? event.toolResults.map(serializeMessage)
        : [],
    };
  }
  return { type: event.type };
};

const getToolLimitMessage = (toolName) => {
  if (toolName === "deepwiki_search") {
    return "deepwiki_search 本轮调用次数已达上限，不要继续检索。请基于已有信息继续完成当前任务。";
  }
  if (toolName === "import_plugin") {
    return "import_plugin 本轮调用次数已达上限。请不要继续导入；直接向用户说明最后一次失败原因和需要修复的位置。";
  }
  return `${toolName} 本轮调用次数已达上限。请停止重复调用该工具，基于已有结果继续当前任务，或换用更合适的工具。`;
};

const createGuardedTool = (tool, runtime) => ({
  ...tool,
  execute: async (toolCallId, params) => {
    runtime.totalToolCalls += 1;
    if (runtime.totalToolCalls > MAX_TOTAL_TOOL_CALLS) {
      throw new Error(`工具调用次数超过上限：${MAX_TOTAL_TOOL_CALLS}`);
    }

    const toolName = tool.name;
    const nextCount = (runtime.toolCallCounts.get(toolName) || 0) + 1;
    runtime.toolCallCounts.set(toolName, nextCount);
    const limit = TOOL_CALL_LIMITS[toolName];
    if (limit && nextCount > limit) {
      return {
        content: [
          {
            type: "text",
            text: getToolLimitMessage(toolName),
          },
        ],
        details: {
          limited: true,
          toolName,
          limit,
        },
      };
    }

    try {
      return await tool.execute(toolCallId, params);
    } catch (error) {
      return toToolFailureResult(toolName, error);
    }
  },
});

const createRuntimeTools = (runtime) =>
  [
    createImportPluginTool(runtime),
    createSelectedImagePathsTool(runtime),
    createShellTool(runtime),
    createDeepWikiTool(),
    createImageSearchTool(),
  ].map((tool) => createGuardedTool(tool, runtime));

const normalizeSelectedImagePaths = (paths) => {
  if (!Array.isArray(paths)) return [];
  return Array.from(
    new Set(
      paths
        .map((item) => String(item || "").trim())
        .filter(Boolean),
    ),
  );
};

const setRuntimeTurnContext = (runtime, payload) => {
  runtime.selectedImagePaths = normalizeSelectedImagePaths(payload?.selectedImagePaths);
};

const createRuntime = (context, payload) => {
  const runtime = {
    storageDir: context.storageDir,
    commandDir: context.commandDir,
    pluginDir: context.pluginDir,
    selectedImagePaths: [],
    totalToolCalls: 0,
    toolCallCounts: new Map(),
  };
  setRuntimeTurnContext(runtime, payload);
  runtime.systemInfo = createSystemInfo(runtime);
  return runtime;
};

const resetRuntimeTurnLimits = (runtime) => {
  runtime.totalToolCalls = 0;
  runtime.toolCallCounts = new Map();
};

const getSettingsSignature = (settings) =>
  JSON.stringify({
    baseUrl: String(settings?.baseUrl || ""),
    model: String(settings?.model || ""),
    userRules: String(settings?.userRules || ""),
  });

const createAgentSession = ({ conversationId, payload, context }) => {
  const settings = payload?.settings || {};
  const runtime = createRuntime(context, payload);
  const session = {
    id: conversationId,
    signature: getSettingsSignature(settings),
    runtime,
    apiKey: String(settings.apiKey || "").trim(),
    agent: null,
    currentTask: null,
    updatedAt: Date.now(),
  };

  const model = createOpenAiCompatibleModel(settings);
  const agent = new Agent({
    initialState: {
      systemPrompt: buildSystemPrompt(runtime.systemInfo, settings),
      model,
      messages: restoreToolTranscriptFromEvents(payload?.messages, payload?.toolEvents, model),
      tools: createRuntimeTools(runtime),
      thinkingLevel: "off",
    },
    streamFn: streamSimple,
    getApiKey: () => session.apiKey,
    toolExecution: "sequential",
    convertToLlm: (messages) =>
      normalizeMessagesForLlm(messages),
  });

  session.agent = agent;
  agent.subscribe((event) => {
    const task = session.currentTask;
    if (!task) return;
    pushTaskEvent(task, normalizeEvent(event));
  });
  sessions.set(conversationId, session);
  return session;
};

const getAgentSession = ({ payload, context }) => {
  const conversationId = String(payload?.conversationId || "").trim();
  if (!conversationId) throw new Error("缺少 conversationId");

  const settings = payload?.settings || {};
  const signature = getSettingsSignature(settings);
  const existing = sessions.get(conversationId);
  if (existing?.signature === signature) {
    existing.apiKey = String(settings.apiKey || "").trim();
    existing.updatedAt = Date.now();
    setRuntimeTurnContext(existing.runtime, payload);
    resetRuntimeTurnLimits(existing.runtime);
    return existing;
  }

  sessions.delete(conversationId);
  return createAgentSession({ conversationId, payload, context });
};

const createTask = () => {
  const task = {
    id: createTaskId(),
    cursor: 0,
    events: [],
    status: "running",
    error: "",
    result: null,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    agent: null,
  };
  tasks.set(task.id, task);
  return task;
};

const pushTaskEvent = (task, event) => {
  task.cursor += 1;
  task.updatedAt = Date.now();
  task.events.push({
    cursor: task.cursor,
    event,
  });
  if (task.events.length > 800) {
    task.events.splice(0, task.events.length - 800);
  }
};

const cleanupTasks = () => {
  const now = Date.now();
  for (const [taskId, task] of tasks.entries()) {
    if (task.status === "running") continue;
    if (now - task.updatedAt > TASK_TTL_MS) tasks.delete(taskId);
  }
  for (const [sessionId, session] of sessions.entries()) {
    if (session.currentTask?.status === "running") continue;
    if (now - session.updatedAt > SESSION_TTL_MS) sessions.delete(sessionId);
  }
};

export const startTurn = async (payload, context) => {
  cleanupTasks();
  const settings = payload?.settings || {};
  const apiKey = String(settings.apiKey || "").trim();
  const prompt = String(payload?.prompt || "").trim();
  if (!apiKey) throw new Error("请先配置 API Key");
  if (!prompt) throw new Error("请输入消息");

  const session = getAgentSession({ payload, context });
  if (session.currentTask?.status === "running") {
    throw new Error("当前会话已有任务正在运行");
  }

  const task = createTask();
  task.agent = session.agent;
  session.currentTask = task;
  session.updatedAt = Date.now();

  void session.agent
    .prompt(prompt)
    .then(() => {
      task.status = "completed";
      task.result = {
        messages: toStoredMessages(session.agent.state.messages),
      };
      task.updatedAt = Date.now();
      session.updatedAt = Date.now();
      session.currentTask = null;
    })
    .catch((error) => {
      task.status = "failed";
      task.error = error instanceof Error ? error.message : String(error);
      task.updatedAt = Date.now();
      session.updatedAt = Date.now();
      session.currentTask = null;
      pushTaskEvent(task, { type: "error", error: task.error });
    });

  return { taskId: task.id };
};

export const pollTurn = async (payload) => {
  cleanupTasks();
  const taskId = String(payload?.taskId || "").trim();
  const after = Number(payload?.cursor || 0);
  const task = tasks.get(taskId);
  if (!task) throw new Error("任务不存在或已过期");
  return {
    taskId,
    status: task.status,
    cursor: task.cursor,
    events: task.events.filter((entry) => entry.cursor > after),
    result: task.status === "completed" ? task.result : null,
    error: task.error,
  };
};

export const cancelTurn = async (payload) => {
  const taskId = String(payload?.taskId || "").trim();
  const task = tasks.get(taskId);
  if (!task) return { success: true };
  task.agent?.abort?.();
  task.status = "cancelled";
  task.updatedAt = Date.now();
  for (const session of sessions.values()) {
    if (session.currentTask?.id === taskId) {
      session.currentTask = null;
      session.updatedAt = Date.now();
    }
  }
  pushTaskEvent(task, { type: "cancelled" });
  return { success: true };
};

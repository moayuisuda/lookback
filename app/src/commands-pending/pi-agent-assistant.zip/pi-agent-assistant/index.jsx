const COMMAND_ID = "piAgentAssistant";
const SETTINGS_KEY = "lookback.command.piAgentAssistant.settings.v1";
const CONVERSATION_KEY = "lookback.command.piAgentAssistant.conversation.v1";
const DEFAULT_BASE_URL = "https://zenmux.ai/api/v1";
const DEFAULT_MODEL = "moonshotai/kimi-k2.7-code-free";
const POLL_INTERVAL_MS = 500;

export const config = {
  id: COMMAND_ID,
  titleKey: "command.piAgentAssistant.title",
  title: "Pi Agent Assistant",
  descriptionKey: "command.piAgentAssistant.description",
  description: "Generate, import, and validate LookBack commands with Pi Agent",
  keywords: ["pi", "agent", "plugin", "command", "assistant", "插件", "命令助手"],
  i18n: {
    en: {
      "command.piAgentAssistant.title": "Pi Agent Assistant",
      "command.piAgentAssistant.description": "Generate, import, and validate LookBack commands with Pi Agent",
      "command.piAgentAssistant.baseUrl": "Base URL",
      "command.piAgentAssistant.apiKey": "API Key",
      "command.piAgentAssistant.model": "Model",
      "command.piAgentAssistant.save": "Saved",
      "command.piAgentAssistant.clear": "Clear",
      "command.piAgentAssistant.cancel": "Stop",
      "command.piAgentAssistant.send": "Send",
      "command.piAgentAssistant.placeholder": "Describe the command you want to build...",
      "command.piAgentAssistant.empty": "No messages yet",
      "command.piAgentAssistant.emptyHint": "Ask the assistant to design, generate, and validate a LookBack command.",
      "command.piAgentAssistant.status.ready": "Ready",
      "command.piAgentAssistant.status.running": "Agent is working...",
      "command.piAgentAssistant.status.completed": "Completed",
      "command.piAgentAssistant.status.failed": "Failed: {{error}}",
      "command.piAgentAssistant.status.cancelled": "Stopped",
      "command.piAgentAssistant.tools": "Tool Activity",
      "command.piAgentAssistant.user": "You",
      "command.piAgentAssistant.assistant": "Assistant",
      "command.piAgentAssistant.tool": "Tool",
      "command.piAgentAssistant.generated": "Plugin imported. Command list refreshed.",
      "command.piAgentAssistant.error.agentFailed": "Agent failed",
      "toast.command.piAgentAssistant.failed": "Pi Agent Assistant failed: {{error}}",
      "toast.command.piAgentAssistant.generated": "Plugin imported and commands refreshed",
      "toast.command.piAgentAssistant.cleared": "Conversation cleared",
    },
    zh: {
      "command.piAgentAssistant.title": "Pi Agent 助手",
      "command.piAgentAssistant.description": "用 Pi Agent 生成、导入并验证 LookBack 命令",
      "command.piAgentAssistant.baseUrl": "Base URL",
      "command.piAgentAssistant.apiKey": "API Key",
      "command.piAgentAssistant.model": "模型",
      "command.piAgentAssistant.save": "已保存",
      "command.piAgentAssistant.clear": "清空",
      "command.piAgentAssistant.cancel": "停止",
      "command.piAgentAssistant.send": "发送",
      "command.piAgentAssistant.placeholder": "描述你想构建的命令...",
      "command.piAgentAssistant.empty": "还没有对话",
      "command.piAgentAssistant.emptyHint": "让助手帮你设计、生成并验证一个 LookBack 命令。",
      "command.piAgentAssistant.status.ready": "就绪",
      "command.piAgentAssistant.status.running": "Agent 正在工作...",
      "command.piAgentAssistant.status.completed": "已完成",
      "command.piAgentAssistant.status.failed": "失败：{{error}}",
      "command.piAgentAssistant.status.cancelled": "已停止",
      "command.piAgentAssistant.tools": "工具活动",
      "command.piAgentAssistant.user": "你",
      "command.piAgentAssistant.assistant": "助手",
      "command.piAgentAssistant.tool": "工具",
      "command.piAgentAssistant.generated": "插件已导入，命令列表已刷新。",
      "command.piAgentAssistant.error.agentFailed": "Agent 执行失败",
      "toast.command.piAgentAssistant.failed": "Pi Agent 助手失败：{{error}}",
      "toast.command.piAgentAssistant.generated": "插件已导入并刷新命令列表",
      "toast.command.piAgentAssistant.cleared": "对话已清空",
    },
  },
};

const parseJson = (value, fallback) => {
  if (!value) return fallback;
  return JSON.parse(value);
};

const loadSettings = () => ({
  baseUrl: DEFAULT_BASE_URL,
  apiKey: "",
  model: DEFAULT_MODEL,
  ...parseJson(localStorage.getItem(SETTINGS_KEY), {}),
});

const saveSettings = (settings) => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
};

const loadConversation = () => ({
  messages: parseJson(localStorage.getItem(CONVERSATION_KEY), { messages: [] }).messages || [],
});

const saveConversation = (conversation) => {
  localStorage.setItem(CONVERSATION_KEY, JSON.stringify(conversation));
};

const getMessageText = (message) => {
  const content = message?.content;
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content
    .filter((block) => block?.type === "text")
    .map((block) => block.text)
    .join("");
};

const getRoleKey = (role) => {
  if (role === "user") return "command.piAgentAssistant.user";
  if (role === "assistant") return "command.piAgentAssistant.assistant";
  return "command.piAgentAssistant.tool";
};

const isGeneratedPluginEvent = (event) =>
  event?.type === "tool_execution_end" && Boolean(event?.result?.details?.generatedPlugin);

const ensureStyles = () => {
  const styleId = "pi-agent-assistant-style";
  if (document.getElementById(styleId)) return;
  const style = document.createElement("style");
  style.id = styleId;
  style.textContent = `
    .pi-agent-shell {
      height: 100%;
      min-height: 0;
      display: grid;
      grid-template-columns: 280px minmax(0, 1fr);
      background: #0a0a0a;
      color: #f5f5f5;
      overflow: hidden;
    }
    .pi-agent-sidebar {
      min-width: 0;
      border-right: 1px solid rgba(64, 64, 64, 0.9);
      background: linear-gradient(180deg, rgba(23, 23, 23, 0.96), rgba(10, 10, 10, 0.98));
      padding: 14px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    .pi-agent-field {
      display: flex;
      flex-direction: column;
      gap: 6px;
      min-width: 0;
    }
    .pi-agent-label {
      font-size: 12px;
      color: #a3a3a3;
    }
    .pi-agent-input,
    .pi-agent-textarea {
      width: 100%;
      min-width: 0;
      border: 1px solid #404040;
      border-radius: 8px;
      background: #171717;
      color: #f5f5f5;
      outline: none;
      padding: 8px 10px;
      font-size: 13px;
    }
    .pi-agent-input:focus,
    .pi-agent-textarea:focus {
      border-color: #39c5bb;
      box-shadow: 0 0 0 2px rgba(57, 197, 187, 0.16);
    }
    .pi-agent-main {
      min-width: 0;
      min-height: 0;
      display: grid;
      grid-template-rows: minmax(0, 1fr) auto;
    }
    .pi-agent-scroll {
      min-height: 0;
      overflow: auto;
      padding: 16px;
    }
    .pi-agent-message {
      max-width: 860px;
      margin: 0 0 12px;
      border: 1px solid #262626;
      border-radius: 8px;
      background: rgba(23, 23, 23, 0.86);
      overflow: hidden;
    }
    .pi-agent-message--user {
      margin-left: auto;
      border-color: rgba(57, 197, 187, 0.45);
      background: rgba(57, 197, 187, 0.08);
    }
    .pi-agent-message-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid #262626;
      padding: 8px 10px;
      color: #a3a3a3;
      font-size: 12px;
    }
    .pi-agent-message-body {
      white-space: pre-wrap;
      word-break: break-word;
      line-height: 1.6;
      padding: 10px;
      font-size: 13px;
      color: #e5e5e5;
    }
    .pi-agent-empty {
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 8px;
      text-align: center;
      color: #737373;
    }
    .pi-agent-tools {
      margin-top: 16px;
      border-top: 1px solid #262626;
      padding-top: 12px;
    }
    .pi-agent-tool-row {
      display: flex;
      justify-content: space-between;
      gap: 12px;
      border: 1px solid #262626;
      border-radius: 8px;
      background: rgba(38, 38, 38, 0.55);
      padding: 8px 10px;
      margin-top: 8px;
      font-size: 12px;
      color: #d4d4d4;
    }
    .pi-agent-compose {
      border-top: 1px solid #262626;
      background: rgba(10, 10, 10, 0.96);
      padding: 12px;
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 10px;
    }
    .pi-agent-textarea {
      min-height: 72px;
      resize: vertical;
      line-height: 1.5;
    }
    .pi-agent-actions {
      display: flex;
      flex-direction: column;
      gap: 8px;
      align-items: stretch;
    }
    .pi-agent-button {
      height: 34px;
      min-width: 74px;
      border: 1px solid #404040;
      border-radius: 8px;
      background: #171717;
      color: #f5f5f5;
      font-size: 13px;
      cursor: pointer;
    }
    .pi-agent-button:hover {
      border-color: #39c5bb;
    }
    .pi-agent-button:disabled {
      cursor: not-allowed;
      opacity: 0.55;
    }
    .pi-agent-button--primary {
      border-color: #39c5bb;
      background: #39c5bb;
      color: #050505;
      font-weight: 600;
    }
    .pi-agent-button--danger {
      border-color: rgba(239, 68, 68, 0.7);
      color: #fca5a5;
      background: rgba(127, 29, 29, 0.35);
    }
    .pi-agent-status {
      margin-top: auto;
      border: 1px solid #262626;
      border-radius: 8px;
      padding: 10px;
      color: #a3a3a3;
      font-size: 12px;
      line-height: 1.5;
      background: rgba(23, 23, 23, 0.7);
    }
  `;
  document.head.appendChild(style);
};

export const ui = ({ context, plugin }) => {
  const { React, hooks, actions } = context;
  const { useEffect, useRef, useState } = React;
  const { t } = hooks.useT();

  ensureStyles();

  const [settings, setSettings] = useState(loadSettings);
  const [conversation, setConversation] = useState(loadConversation);
  const [input, setInput] = useState("");
  const [status, setStatus] = useState({ key: "command.piAgentAssistant.status.ready" });
  const [isRunning, setIsRunning] = useState(false);
  const [draftText, setDraftText] = useState("");
  const [toolEvents, setToolEvents] = useState([]);
  const taskRef = useRef({ taskId: "", cursor: 0, cancelled: false });
  const settingsRef = useRef(settings);
  const conversationRef = useRef(conversation);

  const writeSettings = (patch) => {
    const next = { ...settingsRef.current, ...patch };
    settingsRef.current = next;
    saveSettings(next);
    setSettings(next);
  };

  const writeConversation = (next) => {
    conversationRef.current = next;
    saveConversation(next);
    setConversation(next);
  };

  const appendToolEvent = (event) => {
    setToolEvents((items) => [...items.slice(-7), event]);
  };

  const handleGeneratedPlugin = async () => {
    await actions.commandActions.loadExternalCommands();
    actions.globalActions.pushToast(
      { key: "toast.command.piAgentAssistant.generated" },
      "success",
    );
    appendToolEvent({ type: "generated", toolName: t("command.piAgentAssistant.generated") });
  };

  const consumeEvents = async (entries) => {
    for (const entry of entries) {
      const event = entry.event;
      if (event.type === "message_update" && event.delta) {
        setDraftText((value) => `${value}${event.delta}`);
      }
      if (event.type === "message_start" && event.role === "assistant") {
        setDraftText("");
      }
      if (event.type === "tool_execution_start" || event.type === "tool_execution_end") {
        appendToolEvent(event);
      }
      if (isGeneratedPluginEvent(event)) {
        await handleGeneratedPlugin();
      }
    }
  };

  const pollTask = async (taskId) => {
    while (!taskRef.current.cancelled) {
      const payload = await plugin.invoke("pollTurn", {
        taskId,
        cursor: taskRef.current.cursor,
      });
      taskRef.current.cursor = payload.cursor;
      await consumeEvents(payload.events || []);

      if (payload.status === "completed") {
        const nextMessages = payload.result?.messages || conversationRef.current.messages;
        writeConversation({ messages: nextMessages });
        setDraftText("");
        setStatus({ key: "command.piAgentAssistant.status.completed" });
        setIsRunning(false);
        return;
      }
      if (payload.status === "failed") {
        throw new Error(payload.error || t("command.piAgentAssistant.error.agentFailed"));
      }
      if (payload.status === "cancelled") {
        setStatus({ key: "command.piAgentAssistant.status.cancelled" });
        setIsRunning(false);
        return;
      }

      await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MS));
    }
  };

  const handleSend = async () => {
    const prompt = input.trim();
    if (!prompt || isRunning) return;
    try {
      setInput("");
      setIsRunning(true);
      setDraftText("");
      setStatus({ key: "command.piAgentAssistant.status.running" });
      const optimistic = {
        messages: [
          ...conversationRef.current.messages,
          { role: "user", content: prompt, timestamp: Date.now() },
        ],
      };
      writeConversation(optimistic);
      const started = await plugin.invoke("startTurn", {
        settings: settingsRef.current,
        messages: conversationRef.current.messages.slice(0, -1),
        prompt,
      });
      taskRef.current = { taskId: started.taskId, cursor: 0, cancelled: false };
      await pollTask(started.taskId);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setStatus({
        key: "command.piAgentAssistant.status.failed",
        params: { error: message },
      });
      setIsRunning(false);
      actions.globalActions.pushToast(
        { key: "toast.command.piAgentAssistant.failed", params: { error: message } },
        "error",
      );
    }
  };

  const handleCancel = async () => {
    const taskId = taskRef.current.taskId;
    taskRef.current.cancelled = true;
    if (taskId) await plugin.invoke("cancelTurn", { taskId });
    setIsRunning(false);
    setStatus({ key: "command.piAgentAssistant.status.cancelled" });
  };

  const handleClear = () => {
    const next = { messages: [] };
    writeConversation(next);
    setDraftText("");
    setToolEvents([]);
    actions.globalActions.pushToast(
      { key: "toast.command.piAgentAssistant.cleared" },
      "success",
    );
  };

  const handleInputKeyDown = (event) => {
    if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
      event.preventDefault();
      void handleSend();
    }
  };

  const messages = conversation.messages || [];
  const statusText = t(status.key, status.params);

  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  useEffect(() => {
    conversationRef.current = conversation;
  }, [conversation]);

  return (
    <div className="pi-agent-shell">
      <aside className="pi-agent-sidebar">
        <label className="pi-agent-field">
          <span className="pi-agent-label">{t("command.piAgentAssistant.baseUrl")}</span>
          <input
            className="pi-agent-input"
            value={settings.baseUrl}
            onChange={(event) => writeSettings({ baseUrl: event.target.value })}
          />
        </label>
        <label className="pi-agent-field">
          <span className="pi-agent-label">{t("command.piAgentAssistant.apiKey")}</span>
          <input
            className="pi-agent-input"
            type="password"
            value={settings.apiKey}
            onChange={(event) => writeSettings({ apiKey: event.target.value })}
          />
        </label>
        <label className="pi-agent-field">
          <span className="pi-agent-label">{t("command.piAgentAssistant.model")}</span>
          <input
            className="pi-agent-input"
            value={settings.model}
            onChange={(event) => writeSettings({ model: event.target.value })}
          />
        </label>
        <button
          type="button"
          className="pi-agent-button pi-agent-button--danger"
          onClick={handleClear}
          disabled={isRunning}
        >
          {t("command.piAgentAssistant.clear")}
        </button>
        <div className="pi-agent-status">{statusText}</div>
      </aside>

      <main className="pi-agent-main">
        <div className="pi-agent-scroll">
          {messages.length === 0 && !draftText ? (
            <div className="pi-agent-empty">
              <div>{t("command.piAgentAssistant.empty")}</div>
              <div>{t("command.piAgentAssistant.emptyHint")}</div>
            </div>
          ) : (
            <>
              {messages.map((message, index) => {
                const role = String(message.role || "");
                const text = getMessageText(message);
                if (!text && role === "toolResult") return null;
                return (
                  <article
                    key={`${role}-${message.timestamp || index}-${index}`}
                    className={`pi-agent-message ${role === "user" ? "pi-agent-message--user" : ""}`}
                  >
                    <div className="pi-agent-message-head">
                      <span>{t(getRoleKey(role))}</span>
                    </div>
                    <div className="pi-agent-message-body">{text}</div>
                  </article>
                );
              })}
              {draftText ? (
                <article className="pi-agent-message">
                  <div className="pi-agent-message-head">
                    <span>{t("command.piAgentAssistant.assistant")}</span>
                  </div>
                  <div className="pi-agent-message-body">{draftText}</div>
                </article>
              ) : null}
            </>
          )}

          {toolEvents.length > 0 ? (
            <section className="pi-agent-tools">
              <div className="pi-agent-label">{t("command.piAgentAssistant.tools")}</div>
              {toolEvents.map((event, index) => (
                <div className="pi-agent-tool-row" key={`${event.type}-${index}`}>
                  <span>{event.toolName || t("command.piAgentAssistant.tool")}</span>
                  <span>
                    {event.type === "tool_execution_start"
                      ? t("command.piAgentAssistant.status.running")
                      : event.isError
                        ? t("command.piAgentAssistant.status.failed", { error: "" })
                        : t("command.piAgentAssistant.status.completed")}
                  </span>
                </div>
              ))}
            </section>
          ) : null}
        </div>

        <div className="pi-agent-compose">
          <textarea
            className="pi-agent-textarea"
            value={input}
            onChange={(event) => setInput(event.target.value)}
            onKeyDown={handleInputKeyDown}
            placeholder={t("command.piAgentAssistant.placeholder")}
            disabled={isRunning}
          />
          <div className="pi-agent-actions">
            <button
              type="button"
              className="pi-agent-button pi-agent-button--primary"
              onClick={() => void handleSend()}
              disabled={isRunning || !input.trim()}
            >
              {t("command.piAgentAssistant.send")}
            </button>
            <button
              type="button"
              className="pi-agent-button"
              onClick={() => void handleCancel()}
              disabled={!isRunning}
            >
              {t("command.piAgentAssistant.cancel")}
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

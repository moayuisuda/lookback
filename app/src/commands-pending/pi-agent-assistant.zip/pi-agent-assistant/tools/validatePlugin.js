import path from "node:path";
import { pathToFileURL } from "node:url";
import { transform } from "sucrase";
import { Type } from "@earendil-works/pi-ai";
import {
  assertInside,
  fileLock,
  normalizeRelativePath,
  sanitizeCommandName,
  toCommandPath,
} from "../storage.js";

const SCRIPT_EXTENSIONS = new Set([".js", ".jsx", ".mjs", ".ts", ".tsx"]);
const COMPILE_EXTENSIONS = new Set([".jsx", ".ts", ".tsx"]);

const rewriteImportExtensions = (code) =>
  code.replace(
    /((?:from\s*|import\s*(?:\(\s*)?)["'])(\.{1,2}\/[^"'()]+?)\.(jsx|mjs|tsx|ts)(["'])/g,
    "$1$2.js$4",
  );

const compileSource = (source, filePath) => {
  const ext = path.extname(filePath).toLowerCase();
  if (!SCRIPT_EXTENSIONS.has(ext)) return source;
  const transforms = [];
  if (ext === ".jsx" || ext === ".tsx") transforms.push("jsx");
  if (ext === ".ts" || ext === ".tsx") transforms.push("typescript");
  if (transforms.length === 0) return rewriteImportExtensions(source);
  return rewriteImportExtensions(transform(source, { transforms, production: true }).code);
};

const assertScriptFile = (relativePath) => {
  if (!SCRIPT_EXTENSIONS.has(path.extname(relativePath).toLowerCase())) {
    throw new Error(`入口不是脚本文件：${relativePath}`);
  }
};

const collectScripts = async (rootDir, currentDir = rootDir, result = []) => {
  const entries = await fileLock.readdir(currentDir);
  for (const entry of entries) {
    const fullPath = assertInside(rootDir, path.join(currentDir, entry.name));
    if (entry.isDirectory()) {
      if (["node_modules", ".lookback-esm", ".git"].includes(entry.name)) continue;
      await collectScripts(rootDir, fullPath, result);
      continue;
    }
    if (!entry.isFile()) continue;
    if (SCRIPT_EXTENSIONS.has(path.extname(entry.name).toLowerCase())) {
      result.push(fullPath);
    }
  }
  return result;
};

const validateScriptSyntax = async (filePath) => {
  const source = await fileLock.readText(filePath);
  compileSource(source, filePath);
};

const validateFolderCommand = async (commandDir, target) => {
  const folder = sanitizeCommandName(target);
  const pluginDir = assertInside(commandDir, path.join(commandDir, folder));
  const manifestPath = path.join(pluginDir, "package.json");
  if (!(await fileLock.pathExists(manifestPath))) throw new Error("缺少 package.json");

  const manifest = await fileLock.readJson(manifestPath);
  const lookback = manifest?.lookback && typeof manifest.lookback === "object" ? manifest.lookback : null;
  const id = String(lookback?.id || "").trim();
  const ui = normalizeRelativePath(String(lookback?.ui || ""));
  const server = String(lookback?.server || "").trim()
    ? normalizeRelativePath(String(lookback.server))
    : "";
  if (!id) throw new Error("package.json 缺少 lookback.id");
  assertScriptFile(ui);
  if (server) assertScriptFile(server);

  const uiPath = toCommandPath(pluginDir, ui);
  if (!(await fileLock.pathExists(uiPath))) throw new Error(`缺少 UI 入口：${ui}`);
  if (server) {
    const serverPath = toCommandPath(pluginDir, server);
    if (!(await fileLock.pathExists(serverPath))) throw new Error(`缺少服务端入口：${server}`);
    await import(`${pathToFileURL(serverPath).href}?t=${Date.now()}`);
  }

  const scripts = await collectScripts(pluginDir);
  for (const scriptPath of scripts) {
    await validateScriptSyntax(scriptPath);
  }

  return {
    kind: "folder",
    id,
    folder,
    entry: ui,
    serverEntry: server || undefined,
    scripts: scripts.length,
  };
};

const validateSingleFileCommand = async (commandDir, target) => {
  const relativePath = normalizeRelativePath(target);
  assertScriptFile(relativePath);
  const filePath = toCommandPath(commandDir, relativePath);
  if (!(await fileLock.pathExists(filePath))) throw new Error(`命令文件不存在：${relativePath}`);
  const source = await fileLock.readText(filePath);
  compileSource(source, filePath);
  if (!/export\s+const\s+config\s*=/.test(source)) throw new Error("缺少 export const config");
  if (!/\bid\s*:\s*['"`][^'"`]+['"`]/.test(source)) throw new Error("config 缺少 id");
  return {
    kind: "single-file",
    entry: relativePath,
    scripts: 1,
  };
};

export const validatePlugin = async ({ commandDir, target, kind }) => {
  const targetPath = String(target || "").trim();
  if (!targetPath) throw new Error("缺少验证目标");
  if (kind === "single-file" || path.extname(targetPath)) {
    return validateSingleFileCommand(commandDir, targetPath);
  }
  return validateFolderCommand(commandDir, targetPath);
};

export const createValidatePluginTool = (runtime) => ({
  name: "validate_plugin",
  label: "验证插件",
  description:
    "验证某个 LookBack 外部命令能否合法加载。会检查 manifest、入口、脚本语法，并导入 server entry。",
  parameters: Type.Object({
    target: Type.String({ description: "命令文件名或 folder command 目录名" }),
    kind: Type.Optional(Type.String({ description: "single-file 或 folder；不填则自动判断" })),
  }),
  execute: async (_toolCallId, params) => {
    const result = await validatePlugin({
      commandDir: runtime.commandDir,
      target: params.target,
      kind: params.kind,
    });
    return {
      content: [{ type: "text", text: JSON.stringify(result, null, 2) }],
      details: result,
    };
  },
});

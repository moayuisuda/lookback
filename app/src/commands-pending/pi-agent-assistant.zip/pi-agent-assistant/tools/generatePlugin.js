import path from "node:path";
import { Type } from "@earendil-works/pi-ai";
import {
  assertInside,
  fileLock,
  normalizeRelativePath,
  sanitizeCommandName,
  toCommandPath,
} from "../storage.js";
import { validatePlugin } from "./validatePlugin.js";

const MAX_FILE_SIZE = 1024 * 1024;

const normalizeFile = (file) => {
  const relativePath = normalizeRelativePath(file?.relativePath);
  const content = String(file?.content ?? "");
  if (!content.trim()) throw new Error(`文件内容为空：${relativePath}`);
  if (content.length > MAX_FILE_SIZE) throw new Error(`文件过大：${relativePath}`);
  return { relativePath, content };
};

const assertNoDangerousPath = (relativePath) => {
  if (
    relativePath === "node_modules" ||
    relativePath.startsWith("node_modules/") ||
    relativePath.startsWith(".git/")
  ) {
    throw new Error(`禁止写入该路径：${relativePath}`);
  }
};

const writeSingleFileCommand = async ({ commandDir, pluginId, files, overwrite }) => {
  if (files.length !== 1) throw new Error("单文件命令只能写入一个文件");
  const [file] = files;
  const fileName = `${sanitizeCommandName(pluginId)}${path.extname(file.relativePath) || ".jsx"}`;
  const destPath = assertInside(commandDir, path.join(commandDir, fileName));
  if (!overwrite && (await fileLock.pathExists(destPath))) {
    throw new Error(`命令已存在：${fileName}`);
  }
  await fileLock.writeText(destPath, file.content);
  return { target: fileName, path: destPath };
};

const ensureFolderManifest = (pluginId, files) => {
  if (files.some((file) => file.relativePath === "package.json")) return files;
  return [
    {
      relativePath: "package.json",
      content: `${JSON.stringify(
        {
          name: sanitizeCommandName(pluginId),
          version: "1.0.0",
          private: true,
          type: "module",
          lookback: {
            id: pluginId,
            ui: "index.jsx",
          },
        },
        null,
        2,
      )}\n`,
    },
    ...files,
  ];
};

const writeFolderCommand = async ({ commandDir, pluginId, files, overwrite }) => {
  const folderName = sanitizeCommandName(pluginId);
  const folderPath = assertInside(commandDir, path.join(commandDir, folderName));
  if (!overwrite && (await fileLock.pathExists(folderPath))) {
    throw new Error(`命令目录已存在：${folderName}`);
  }
  await fileLock.ensureDir(folderPath);
  const nextFiles = ensureFolderManifest(pluginId, files);
  for (const file of nextFiles) {
    assertNoDangerousPath(file.relativePath);
    const destPath = toCommandPath(folderPath, file.relativePath);
    await fileLock.writeText(destPath, file.content);
  }
  return { target: folderName, path: folderPath };
};

export const createGeneratePluginTool = (runtime) => ({
  name: "generate_plugin",
  label: "生成插件",
  description:
    "写入并导入一个 LookBack 外部命令。优先生成单文件 .jsx；复杂场景生成 folder command，并提供 package.json、index.jsx、server.js 等完整文件。",
  parameters: Type.Object({
    pluginId: Type.String({ description: "命令 ID，使用驼峰或短横线命名" }),
    mode: Type.String({ description: "single-file 或 folder" }),
    overwrite: Type.Optional(Type.Boolean({ description: "是否覆盖已存在命令，默认 false" })),
    files: Type.Array(
      Type.Object({
        relativePath: Type.String({ description: "相对路径，例如 index.jsx 或 tools/search.js" }),
        content: Type.String({ description: "完整源码内容" }),
      }),
      { minItems: 1 },
    ),
  }),
  executionMode: "sequential",
  execute: async (_toolCallId, params) => {
    const pluginId = sanitizeCommandName(params.pluginId);
    const mode = params.mode === "folder" ? "folder" : "single-file";
    const files = params.files.map(normalizeFile);
    const imported =
      mode === "folder"
        ? await writeFolderCommand({
            commandDir: runtime.commandDir,
            pluginId,
            files,
            overwrite: params.overwrite === true,
          })
        : await writeSingleFileCommand({
            commandDir: runtime.commandDir,
            pluginId,
            files,
            overwrite: params.overwrite === true,
          });

    const validation = await validatePlugin({
      commandDir: runtime.commandDir,
      target: imported.target,
      kind: mode === "folder" ? "folder" : "single-file",
    });

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(
            {
              imported: true,
              mode,
              target: imported.target,
              validation,
            },
            null,
            2,
          ),
        },
      ],
      details: {
        generatedPlugin: {
          mode,
          target: imported.target,
        },
      },
    };
  },
});
